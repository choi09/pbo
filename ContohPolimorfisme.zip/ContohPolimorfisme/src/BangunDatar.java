/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class BangunDatar {
    float luas(){
        System.out.println("menghitung luas bangun datar");
        return 0;
    }
    
    float keliling (){
        System.out.println("menghitung keliling bangun datar");
        return 0;
    }
    
}
